﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
   
    public static class MyExtMethod
    {
        public static IList<Users> SearchListName(this string name)
        {
            IList<Users> usersList = Users.SetListUser();
            IList<Users> users2 = new List<Users>();
            foreach (Users usr in usersList)
            {
                if (usr.FirstName == name)
                    users2.Add(usr);
            }
            return users2;
        }
        public static IList<Users> SearchListRole(this string role)
        {
            IList<Users> usersList = Users.SetListUser();
            IList<Users> users2 = new List<Users>();
            foreach (Users usr in usersList)
            {
                if (usr.Rolename == role)
                    users2.Add(usr);
            }
            return users2;
        }
        public static IList<Users> SearchListage(this string age)
        {
            IList<Users> usersList = Users.SetListUser();
            IList<Users> users2 = new List<Users>();
            foreach (Users usr in usersList)
            {
                if (usr.Age >= Convert.ToInt32(age))
                    users2.Add(usr);
            }
            return users2;
        }
    }
}
