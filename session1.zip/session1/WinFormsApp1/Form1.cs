﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
        Users _users = new Users();
        public delegate IList<Users> searchGrid(string obj);
      

      
      
        private void Form1_Load(object sender, EventArgs e)
        {
           

            dataGridView1.DataSource = Users.SetListUser();
           
        }

     

        private void btnage_Click(object sender, EventArgs e)
        {
            
            searchGrid del = new searchGrid(Users.SearchAge);
            IList<Users> userList2 = del(txtage.Text);
            dataGridView1.DataSource = userList2;
        }

   

        private void btnroleid_Click(object sender, EventArgs e)
        {

            searchGrid del = new searchGrid(Users.SearchRole);
            IList<Users> userList2 = del( cmbRole.SelectedItem.ToString());
            dataGridView1.DataSource = userList2;
        }

        private void btnName_Click_1(object sender, EventArgs e)
        {
            searchGrid del = new searchGrid(Users.SearchName);
            IList<Users> userList2 = del( txtname.Text);
            dataGridView1.DataSource = userList2;
        }
    }
}
