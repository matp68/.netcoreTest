﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Formfunc : Form
    {
        public Formfunc()
        {
            InitializeComponent();
        }
       
      
        Users _users = new Users();
      




        private void Formfunc_Load(object sender, EventArgs e)
        {


            dataGridView1.DataSource = Users.SetListUser();

        }

     

        private void btnage_Click(object sender, EventArgs e)
        {

            Func<string , IList<Users>> searchList = Users.SearchAge;

            IList<Users> result = searchList(txtage.Text);

            dataGridView1.DataSource = result;
        }

        private void btnName_Click(object sender, EventArgs e)
        {

            Func< string, IList<Users>> searchList = Users.SearchName;

            IList<Users> result = searchList(txtname.Text);

            dataGridView1.DataSource = result;
        }

        private void btnroleid3_Click(object sender, EventArgs e)
        {
            Func<string, IList<Users>> searchList = Users.SearchRole;

            IList<Users> result = searchList(cmbRole.SelectedItem.ToString());

            dataGridView1.DataSource = result;
        }

    
    }
}
