﻿
namespace WinFormsApp1
{
    partial class Formfunc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.f = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FirsName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lastname = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.roleid = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnroleid = new System.Windows.Forms.Button();
            this.btnName = new System.Windows.Forms.Button();
            this.btnage = new System.Windows.Forms.Button();
            this.cmbRole = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtage = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id,
            this.f,
            this.FirsName,
            this.Lastname,
            this.Column2,
            this.Column3,
            this.Column4,
            this.roleid});
            this.dataGridView1.Location = new System.Drawing.Point(-1, 116);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(789, 332);
            this.dataGridView1.TabIndex = 2;
            // 
            // id
            // 
            this.id.DataPropertyName = "Userid";
            this.id.HeaderText = "شناسه";
            this.id.Name = "id";
            // 
            // f
            // 
            this.f.DataPropertyName = "Username";
            this.f.HeaderText = "نام کاربری";
            this.f.Name = "f";
            // 
            // FirsName
            // 
            this.FirsName.DataPropertyName = "FirstName";
            this.FirsName.HeaderText = "نام";
            this.FirsName.Name = "FirsName";
            // 
            // Lastname
            // 
            this.Lastname.DataPropertyName = "Lastname";
            this.Lastname.HeaderText = "نام خانوادگی";
            this.Lastname.Name = "Lastname";
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "Mobile";
            this.Column2.HeaderText = "موبایل";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "Age";
            this.Column3.HeaderText = "سن";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "Rolename";
            this.Column4.HeaderText = "نقش";
            this.Column4.Name = "Column4";
            // 
            // roleid
            // 
            this.roleid.DataPropertyName = "Roleid";
            this.roleid.HeaderText = "شناسه نقش";
            this.roleid.Name = "roleid";
            // 
            // btnroleid
            // 
            this.btnroleid.Location = new System.Drawing.Point(309, 73);
            this.btnroleid.Name = "btnroleid";
            this.btnroleid.Size = new System.Drawing.Size(207, 23);
            this.btnroleid.TabIndex = 5;
            this.btnroleid.Text = "تایید";
            this.btnroleid.UseVisualStyleBackColor = true;
            this.btnroleid.Click += new System.EventHandler(this.btnroleid3_Click);
            // 
            // btnName
            // 
            this.btnName.Location = new System.Drawing.Point(40, 73);
            this.btnName.Name = "btnName";
            this.btnName.Size = new System.Drawing.Size(207, 23);
            this.btnName.TabIndex = 4;
            this.btnName.Text = "تایید ";
            this.btnName.UseVisualStyleBackColor = true;
            this.btnName.Click += new System.EventHandler(this.btnName_Click);
            // 
            // btnage
            // 
            this.btnage.Location = new System.Drawing.Point(581, 73);
            this.btnage.Name = "btnage";
            this.btnage.Size = new System.Drawing.Size(207, 23);
            this.btnage.TabIndex = 3;
            this.btnage.Text = "تایید";
            this.btnage.UseVisualStyleBackColor = true;
            this.btnage.Click += new System.EventHandler(this.btnage_Click);
            // 
            // cmbRole
            // 
            this.cmbRole.FormattingEnabled = true;
            this.cmbRole.Items.AddRange(new object[] {
            "guest",
            "admin",
            "manager"});
            this.cmbRole.Location = new System.Drawing.Point(309, 32);
            this.cmbRole.Name = "cmbRole";
            this.cmbRole.Size = new System.Drawing.Size(104, 23);
            this.cmbRole.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(419, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(107, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "نمایش افراد با نقش  ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(661, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 15);
            this.label4.TabIndex = 9;
            this.label4.Text = "نمایش افراد با سن بالاتر از";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(143, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 15);
            this.label2.TabIndex = 10;
            this.label2.Text = "نمایش افراد با نام";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(589, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 15);
            this.label1.TabIndex = 11;
            this.label1.Text = "سال";
            // 
            // txtage
            // 
            this.txtage.Location = new System.Drawing.Point(619, 35);
            this.txtage.Name = "txtage";
            this.txtage.Size = new System.Drawing.Size(42, 23);
            this.txtage.TabIndex = 6;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(40, 29);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(97, 23);
            this.txtname.TabIndex = 7;
            // 
            // Formfunc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cmbRole);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtage);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.btnage);
            this.Controls.Add(this.btnName);
            this.Controls.Add(this.btnroleid);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Formfunc";
            this.Text = "Formfunc";
            this.Load += new System.EventHandler(this.Formfunc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn id;
        private System.Windows.Forms.DataGridViewTextBoxColumn f;
        private System.Windows.Forms.DataGridViewTextBoxColumn FirsName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Lastname;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn roleid;
        private System.Windows.Forms.Button btnroleid;
        private System.Windows.Forms.Button btnName;
        private System.Windows.Forms.Button btnage;
        private System.Windows.Forms.ComboBox cmbRole;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtage;
        private System.Windows.Forms.TextBox txtname;
    }
}