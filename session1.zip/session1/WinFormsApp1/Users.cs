﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp1
{
    public class Users
    {
        private int userid;
        private string username;
        private string firstname;
        private string lastname;
        private int age;
        private string mobile;
        private int roleid;
        private string rolename;
        public int Userid
        {
            get
            {
                return userid;
            }
            set
            {
                userid = value;
            }
        }
        public string Username
        {
            get
            {
                return username;
            }
            set
            {
                username = value;
            }
        }
        public string FirstName
        {
            get
            {
                return firstname;
            }
            set
            {
                firstname = value;
            }
        }
        public string Lastname
        {
            get
            {
                return lastname;
            }
            set
            {
                lastname = value;
            }
        }
        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
            }
        }

        public string Mobile
        {
            get
            {
                return mobile;
            }
            set
            {
                mobile = value;
            }
        }
        public int Roleid
        {
            get
            {
                return roleid;
            }
            set
            {
                roleid = value;
            }
        }
        public string Rolename
        {
            get
            {
                return rolename;
            }
            set
            {
                rolename = value;
            }
        }
        public static IList<Users> SetListUser()
        {
            IList<Users> userList = new List<Users>()
             {
                 new Users(){ Userid=1, Username="username1",FirstName="hasan",Lastname="mohamadi",Mobile="0913245258",Age=30,Roleid=1,Rolename="guest"},
               new Users(){ Userid=2, Username="username2",FirstName="maryam",Lastname="hasani",Mobile="0913245258",Age=23,Roleid=2,Rolename="admin"},
                new Users(){ Userid=3, Username="username3",FirstName="mina",Lastname="javid",Mobile="0913258658",Age=50,Roleid=1,Rolename="guest"},
               new Users(){ Userid=4, Username="username4",FirstName="mohammad",Lastname="azadi",Mobile="0913256668",Age=57,Roleid=3,Rolename="manager"},
                new Users(){ Userid=5, Username="username5",FirstName="ali",Lastname="nikan",Mobile="0913258668",Age=45,Roleid=1,Rolename="guest"},
               new Users(){ Userid=6, Username="username6",FirstName="maryam",Lastname="rezai",Mobile="0913257758",Age=32,Roleid=3,Rolename="manager"},
                new Users(){ Userid=7, Username="username7",FirstName="ahmad",Lastname="sedaghat",Mobile="0913778258",Age=33,Roleid=1,Rolename="guest"},
               new Users(){ Userid=8, Username="username8",FirstName="shima",Lastname="norozi",Mobile="0913258278",Age=30,Roleid=1,Rolename="guest"},
                new Users(){ Userid=9, Username="username9",FirstName="ali",Lastname="majd",Mobile="0913258258",Age=65,Roleid=1,Rolename="guest"},
               new Users(){ Userid=10, Username="username10",FirstName="maryam",Lastname="mohamadi",Mobile="091355558",Age=48,Roleid=1,Rolename="guest"},
                new Users(){ Userid=11, Username="username11",FirstName="ali",Lastname="moradi",Mobile="0913254448",Age=41,Roleid=1,Rolename="guest"},
               new Users(){ Userid=12, Username="username12",FirstName="mohammad",Lastname="mohamadi",Mobile="0913338258",Age=39,Roleid=1,Rolename="guest"},
                new Users(){ Userid=13, Username="username13",FirstName="sima",Lastname="azadi",Mobile="0913258233",Age=30,Roleid=1,Rolename="guest"},
               new Users(){ Userid=14, Username="username14",FirstName="reza",Lastname="moghadam",Mobile="0913258238",Age=34,Roleid=2,Rolename="admin"},
                new Users(){ Userid=15, Username="username15",FirstName="ali",Lastname="rahnama",Mobile="0913298765",Age=87,Roleid=3,Rolename="manager"},
               new Users(){ Userid=16, Username="username16",FirstName="mohammad",Lastname="mohamadi",Mobile="0913211111",Age=20,Roleid=2,Rolename="admin"}
            };
            return userList;
        }


        public static IList<Users> SearchRole( string role)
        {
            IList<Users> usersList = SetListUser();
            IList<Users> users2 = new List<Users>();
            foreach (Users usr in usersList)
            {
                if (usr.rolename == role)
                    users2.Add(usr);
            }
            return users2;
        }
        public static IList<Users> SearchName(string name)
        {
            IList<Users> usersList = SetListUser();
            IList<Users> users2 = new List<Users>();
            foreach (Users usr in usersList)
            {
                if (usr.FirstName ==name)
                    users2.Add(usr);
            }
            return users2;
        }
        public static IList<Users> SearchAge(string age)
        {
            IList<Users> usersList = SetListUser();
            IList<Users> users2 = new List<Users>();
            foreach (Users usr in usersList)
            {
                if (usr.Age>=Convert.ToInt32(age))
                    users2.Add(usr);
            }
            return users2;
        }
    }
}
